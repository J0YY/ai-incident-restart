COMPLETED AND VERIFIED. 864 responses, three settings on the same twelve diagnostic bases.

The frozen release_v3 and every prior release remain unchanged. Historical pre-inference status wording inside those releases is intentional. Current completion is recorded in job_record.json and attempt_01/completion.json.

Thinking off/320: 279/288 correct, 0 wrong approvals, 9 withholding failures (8 valid refusals and 1 invalid output).
Thinking off/4096: 279/288 correct, 0 wrong approvals, 9 valid needless refusals, no invalid outputs.
Thinking on/4096: 284/288 correct, 1 wrong approval, no needless withholding, 3 invalid outputs. All invalid outputs reached their cap.
Each arm has 144 supported and 144 unsupported assignments. Treating invalid unsupported decisions as possible approvals gives a thinking-on upper count of 4/144.

Sufficient-test-last withholding under primary / first-listed / decision-only forms: off320 8/24, 1/24 (invalid), 0/24; off4096 8/24, 1/24, 0/24; on4096 0/24 in every form. This is same-case robustness, not independent validation.

The original inference job was preempted after 184 saved responses. The unchanged runner resumed missing batches only. All 23 preemption batch hashes were verified unchanged. Raw outputs, token IDs, both invocation environments, original and resume logs, completion, all condition/base cells and paired transitions are retained. No answer was retried because of its content.

Reanalyze without model inference:
python3 release_v3/scripts/analyze_gemma_reasoning_check.py --run attempt_01

The saved analysis matches local reanalysis and an independent count. See attempt_01/independent_verification.json. README_pre_inference_20261008.txt preserves the preparation instructions. Do not follow its obsolete submission advice or launch another copy of the completed run.
