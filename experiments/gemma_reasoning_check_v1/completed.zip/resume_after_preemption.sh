#!/usr/bin/env bash
#SBATCH --partition=low-prio-gpu
#SBATCH --gres=gpu:h100:1
#SBATCH --cpus-per-task=8
#SBATCH --mem=110G
#SBATCH --time=04:00:00
#SBATCH --requeue
#SBATCH --open-mode=append
#SBATCH --output=/work/joy/emotional-vectors/logs/%x_%j.out
set -euo pipefail
CHECK_RELEASE=/work/joy/emotional-vectors/results/gemma_reasoning_check_v1/release_v3
CHECK_OUTPUT=/work/joy/emotional-vectors/results/gemma_reasoning_check_v1/attempt_01
source "$CHECK_RELEASE/scripts/athena_env.sh"
export HF_HUB_OFFLINE=1
test -f "$CHECK_OUTPUT/run.json"
printf 'RESUME_INVOCATION job=%s restart=%s time=%s\n' "$SLURM_JOB_ID" "${SLURM_RESTART_COUNT:-0}" "$(date -u +%Y-%m-%dT%H:%M:%SZ)"
exec /work/joy/envs/vlm-ros/bin/python "$CHECK_RELEASE/scripts/run_gemma_reasoning_check.py" --release "$CHECK_RELEASE" --output "$CHECK_OUTPUT" --resume
