#!/usr/bin/env bash
#SBATCH --partition=compute
#SBATCH --cpus-per-task=2
#SBATCH --mem=8G
#SBATCH --time=00:15:00
#SBATCH --output=/work/joy/emotional-vectors/logs/%x_%j.out
set -euo pipefail
CHECK_RELEASE=/work/joy/emotional-vectors/results/gemma_reasoning_check_v1/release_v3
CHECK_OUTPUT=/work/joy/emotional-vectors/results/gemma_reasoning_check_v1/attempt_01
source "$CHECK_RELEASE/scripts/athena_env.sh"
exec /work/joy/envs/vlm-ros/bin/python "$CHECK_RELEASE/scripts/analyze_gemma_reasoning_check.py" --run "$CHECK_OUTPUT"
