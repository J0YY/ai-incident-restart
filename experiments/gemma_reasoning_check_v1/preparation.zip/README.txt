PREPARED, UNRUN. No new model outputs exist.

This package repeats all 288 original Gemma diagnostic assignments under three settings, off/320, off/4096, and on/4096. It retains the same pinned model, prompts, eight-response batches, sampler and seeds. It plans 864 responses across twelve existing bases, not 864 independent cases. The 4096 cap includes thought and answer tokens and only numerically matches the API cap.

The current release is release_v3. Release v1 has an unusable Slurm wrapper because Slurm copies the job script to its spool. Version 2 takes the original release directory as an explicit argument. Version 3 preserves each invocation's environment record if a user explicitly resumes an interrupted attempt. No model inference occurred before these revisions. All releases and their hashes remain available.

Offline checks passed six parser/assignment tests, including score agreement for all 288 original Gemma diagnostic outputs. An analysis fixture that reused the same archived outputs in each mock arm confirmed 36 cells, 432 base cells, and zero artificial differences. Fixture data were temporary and are not study outcomes. GPU model loading, chat-template validation, memory capacity and inference remain untested.

Athena's SSH gateway timed out during preparation on October 8, 2026. No job was submitted. Run only after cluster access returns. Use a new output directory and retain all attempts.

From the local emotional-vectors workspace, copy release_v3 to /work/joy/emotional-vectors/results/gemma_reasoning_check_v1/release_v3 on Athena. Then submit on Athena:

sbatch --job-name=gemma_reasoning_v1 /work/joy/emotional-vectors/results/gemma_reasoning_check_v1/release_v3/run_athena.sh /work/joy/emotional-vectors/results/gemma_reasoning_check_v1/release_v3 /work/joy/emotional-vectors/results/gemma_reasoning_check_v1/attempt_01

After completion, run the frozen scripts/analyze_gemma_reasoning_check.py with --run pointing to attempt_01. Report every setting even if reasoning removes every error. Do not change the cap after observing results. The protocol and code specify scoring, raw-output retention and paired comparisons.

Thinking control and output-channel documentation:
https://ai.google.dev/gemma/docs/capabilities/thinking
