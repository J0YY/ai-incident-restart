#!/usr/bin/env bash
#SBATCH --partition=low-prio-gpu
#SBATCH --gres=gpu:h100:1
#SBATCH --cpus-per-task=8
#SBATCH --mem=110G
#SBATCH --time=04:00:00
#SBATCH --output=/work/joy/emotional-vectors/logs/%x_%j.out
set -euo pipefail
CHECK_RELEASE="$(cd "$(dirname "$0")" && pwd)"
source "$CHECK_RELEASE/scripts/athena_env.sh"
export HF_HUB_OFFLINE=1
exec /work/joy/envs/vlm-ros/bin/python "$CHECK_RELEASE/scripts/run_gemma_reasoning_check.py" --release "$CHECK_RELEASE" --output "$1"
