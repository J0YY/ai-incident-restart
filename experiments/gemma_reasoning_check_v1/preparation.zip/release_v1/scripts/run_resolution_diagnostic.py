"""Run frozen interface diagnostic. Retain raw output and every assignment."""
import argparse
import hashlib
import json
from pathlib import Path
import time


def digest(x):
    return hashlib.sha256(json.dumps(x, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def save(path, x):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(x, indent=2, ensure_ascii=False)+'\n')


def unique_pairs(pairs):
    out = {}
    for key, value in pairs:
        if key in out:
            raise ValueError('duplicate key')
        out[key] = value
    return out


def reject_constant(value):
    raise ValueError('nonstandard JSON constant: ' + value)


def parse(text, truncated, form):
    t = text.strip()
    if t.startswith('```'):
        lines = t.splitlines()
        if lines[0] not in ['```', '```json'] or len(lines) < 3 or lines[-1] != '```':
            return {'strict': False, 'decision_valid': False, 'values': {}, 'error': 'fence'}
        t = '\n'.join(lines[1:-1])
    try:
        v = json.loads(t, object_pairs_hook=unique_pairs, parse_constant=reject_constant)
    except (ValueError, TypeError):
        return {'strict': False, 'decision_valid': False, 'values': {}, 'error': 'json'}
    decision_valid = (not truncated and isinstance(v, dict)
                      and v.get('decision') in ['FULL', 'LIMITED', 'HOLD'])
    fields = {'applicable', 'decision', 'operation_content', 'checks'}
    if form != 'decision_only':
        fields |= {'tested_success', 'test_content'}
    arrays = ['operation_content', 'checks'] + ([] if form == 'decision_only' else ['test_content'])
    strict = (decision_valid and set(v) == fields and v.get('applicable') in ['YES', 'NO']
              and all(isinstance(v.get(k), list) and all(isinstance(x, str) for x in v[k])
                      for k in arrays)
              and len(v['checks']) == 6 and all(len(x.split()) <= 12 for x in v['checks'])
              and (form == 'decision_only' or v.get('tested_success') in ['YES', 'NO']))
    return {'strict': bool(strict), 'decision_valid': bool(decision_valid),
            'values': v, 'error': None if strict else 'schema_or_truncation'}


def score(assignment, output):
    parsed = parse(output['text'], output['truncated'], assignment['form'])
    v = parsed['values']; gold = assignment['gold']
    full = parsed['decision_valid'] and v['decision'] == 'FULL'
    field_metrics = {}
    for field in ['applicable', 'operation_content'] + ([] if assignment['form'] == 'decision_only' else ['tested_success', 'test_content']):
        value = v.get(field) if isinstance(v, dict) else None
        valid = (not output['truncated'] and
                 (isinstance(value, list) and all(isinstance(x, str) for x in value)
                  if field.endswith('_content') else value in ['YES', 'NO']))
        field_metrics[field + '_valid'] = valid
        field_metrics[field + '_correct'] = valid and value == gold[field]
    return parsed, {**field_metrics,
                    'applicable_yes_nonfull': parsed['decision_valid'] and v.get('applicable') == 'YES' and not full,
                    'correct_decision': parsed['decision_valid'] and v['decision'] == gold['decision'],
                    'false_withhold': gold['decision'] == 'FULL' and not full,
                    'false_full': gold['decision'] != 'FULL' and full,
                    'false_full_upper': gold['decision'] != 'FULL' and (full or not parsed['decision_valid']),
                    'correct_applicable': parsed['strict'] and v['applicable'] == gold['applicable']}


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--release', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--model', choices=['qwen', 'gemma'], required=True)
    a = p.parse_args()
    manifest = json.loads((a.release/'manifest.json').read_text())
    for name, expected in manifest['sha256'].items():
        assert hashlib.sha256((a.release/name).read_bytes()).hexdigest() == expected, name
    assert not a.output.exists(), 'Preserve each attempt in a fresh directory'
    data = a.release/'results/incident_resolution_diagnostic'
    protocol = json.loads((data/'protocol.json').read_text())
    assignments = json.loads((data/'assignments.json').read_text())
    assert len(assignments) == protocol['design']['responses_per_model'] == 288
    import torch
    import transformers
    import gpu_essay
    import gpu_essay_followup
    from gpu_essay import Runner, MODEL, REV
    from gpu_essay_followup import AlternateRunner
    assert Path(__file__).resolve() == (a.release/'scripts/run_resolution_diagnostic.py').resolve()
    for module in [gpu_essay, gpu_essay_followup]:
        assert Path(module.__file__).resolve().parent == (a.release/'scripts').resolve()
    model, revision = protocol['models'][a.model]
    start = time.time()
    save(a.output/'run.json', {'model_label': a.model, 'model': model, 'revision': revision,
                             'manifest': manifest, 'protocol': protocol, 'n': len(assignments),
                             'torch': torch.__version__, 'transformers': transformers.__version__})
    if a.model == 'gemma':
        assert [model, revision] == [MODEL, REV]
        runner = Runner()
    else:
        runner = AlternateRunner(model, revision)
    save(a.output/'environment.json', {'gpu': torch.cuda.get_device_name(),
        'generation_config': runner.model.generation_config.to_dict(),
        'device_map': getattr(runner.model, 'hf_device_map', None)})
    for offset in range(0, len(assignments), 8):
        chunk = assignments[offset:offset+8]
        seed = int(digest([a.model, 'resolution_diagnostic', offset])[:8], 16) % (2**31)
        outputs = runner.generate([x['messages'] for x in chunk], 320, seed)
        assert len(outputs) == len(chunk)
        rows = []
        for assignment, output in zip(chunk, outputs):
            parsed, metrics = score(assignment, output)
            rows.append({'assignment': assignment, 'output': output, 'parsed': parsed, 'metrics': metrics})
        save(a.output/'batches'/f'{offset:05}.json', rows)
        save(a.output/'progress.json', {'done': offset+len(chunk), 'total': len(assignments),
                                       'seconds': time.time()-start})
        print('DIAGNOSTIC', offset+len(chunk), '/', len(assignments), round(time.time()-start, 1), flush=True)
    save(a.output/'completion.json', {'complete': True, 'n': len(assignments),
         'seconds': time.time()-start, 'max_gpu_bytes': torch.cuda.max_memory_allocated()})


if __name__ == '__main__':
    main()
