"""Reparse every assigned final answer and report complete cells, bases, and paired differences."""
import argparse,json,sys
from collections import Counter
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from run_resolution_diagnostic import score
from run_gemma_reasoning_check import final_answer,save

def summarize(rows):
    return {'n':len(rows),'correct':sum(r['metrics']['correct_decision'] for r in rows),
        'wrong_approvals':sum(r['metrics']['false_full'] for r in rows),
        'wrong_approvals_upper':sum(r['metrics']['false_full_upper'] for r in rows),
        'needless_withholding':sum(r['metrics']['false_withhold'] for r in rows),
        'invalid':sum(not r['parsed']['decision_valid'] for r in rows),
        'truncated':sum(r['output']['truncated'] for r in rows),
        'schema_failures':sum(not r['parsed']['strict'] for r in rows),
        'thought_channel_outputs':sum(r['output']['channel']['thought_channel'] for r in rows),
        'generated_tokens':sum(len(r['output']['new_token_ids']) for r in rows)}

def main():
    p=argparse.ArgumentParser();p.add_argument('--run',type=Path,required=True);a=p.parse_args()
    run=json.loads((a.run/'run.json').read_text());protocol=run['protocol']
    assert json.loads((a.run/'completion.json').read_text())['n']==864
    all_rows={};cells=[];bases=[]
    for arm in protocol['arms']:
        rows=[]
        for file in sorted((a.run/arm['name']/'batches').glob('*.json')):
            rows.extend(json.loads(file.read_text()))
        assert len(rows)==288 and all(r['arm']==arm for r in rows)
        keys=[(r['assignment']['base_id'],r['assignment']['sufficient'],r['assignment']['position'],r['assignment']['form'],r['assignment']['rep']) for r in rows]
        assert len(set(keys))==288
        for row in rows:
            text,channel=final_answer(row['output']['raw_text'])
            assert text==row['output']['text'] and channel==row['output']['channel']
            parsed,metrics=score(row['assignment'],row['output'])
            assert parsed==row['parsed'] and metrics==row['metrics']
        all_rows[arm['name']]=rows
        for sufficient in [False,True]:
            for position in ['first','last']:
                for form in ['primary','first_listed','decision_only']:
                    rr=[r for r in rows if (r['assignment']['sufficient'],r['assignment']['position'],r['assignment']['form'])==(sufficient,position,form)]
                    assert len(rr)==24
                    cells.append({'arm':arm['name'],'sufficient':sufficient,'position':position,'form':form,**summarize(rr)})
                    for base in sorted({r['assignment']['base_id'] for r in rr}):
                        bb=[r for r in rr if r['assignment']['base_id']==base]
                        bases.append({'arm':arm['name'],'sufficient':sufficient,'position':position,'form':form,'base':base,**summarize(bb)})
    def key(r):
        x=r['assignment'];return x['base_id'],x['sufficient'],x['position'],x['form'],x['rep']
    comparisons=[]
    for left,right in [('off_320','off_4096'),('off_4096','on_4096')]:
        aa={key(r):r for r in all_rows[left]};bb={key(r):r for r in all_rows[right]}
        assert aa.keys()==bb.keys()
        transitions=Counter()
        for k in aa:
            assert aa[k]['assignment']==bb[k]['assignment']
            transitions[(aa[k]['metrics']['correct_decision'],bb[k]['metrics']['correct_decision'])]+=1
        comparisons.append({'from':left,'to':right,'n':len(aa),
            'wrong_to_correct':transitions[False,True],'correct_to_wrong':transitions[True,False],
            'both_correct':transitions[True,True],'both_wrong':transitions[False,False]})
    result={'status':'Completed same-case exploratory robustness check, not independent case validation',
        'summaries':{name:summarize(rows) for name,rows in all_rows.items()},'cells':cells,'base_cells':bases,
        'paired_changes':comparisons,'inference_scope':'Descriptive paired counts for the fixed twelve-base bank; no new population significance claim.'}
    save(a.run/'analysis.json',result)
    print(json.dumps({'summaries':result['summaries'],'paired_changes':comparisons},indent=2))

if __name__=='__main__':main()
