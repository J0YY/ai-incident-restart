"""Unsteered multi-turn essay experiment. Writes all assigned sessions, never selects by effects."""
import os,json,time,hashlib,random,re,traceback,argparse
from pathlib import Path
import numpy as np
import torch
import transformers
from transformers import AutoProcessor,AutoModelForMultimodalLM
ROOT=Path('/work/joy/emotional-vectors');MODEL='google/gemma-4-31B-it';REV='842da3794eaa0b77d5f08bae87a17459d91ff475'
def save(p,v):
 p.parent.mkdir(parents=True,exist_ok=True);q=p.with_suffix(p.suffix+'.tmp');q.write_text(json.dumps(v,indent=2,ensure_ascii=False));q.replace(p)
def parse_ratings(text,ids,lo,hi):
 text=text.replace('**','').replace('`','');out={};errors=[]
 for i in ids:
  hits=re.findall(r'(?m)^\s*(?:[-*]\s*|\d+[.)]\s*)?'+re.escape(i)+r'\s*[:=]\s*(-?\d+(?:\.\d+)?)\s*(?:%|/\s*\d+)?\s*[.,]?\s*$',text)
  if len(hits)!=1:errors.append(i+':missing_or_ambiguous');continue
  v=float(hits[0])
  if not lo<=v<=hi:errors.append(i+':out_of_range');continue
  out[i]=v
 return {'values':out,'valid':not errors,'errors':errors}
def parse_choice(text,choices):
 normalized=re.sub(r'\s+',' ',text.strip().lower()).strip(' .!"\'`*\n')
 matches=[i for i,c in enumerate(choices) if normalized==c]
 return {'valid':len(matches)==1,'index':matches[0] if len(matches)==1 else None,'normalized':normalized}
def check_items(groups,seed):
 pairs=[(group,t) for group,ts in groups.items() for t in ts];random.Random(seed).shuffle(pairs)
 return [dict(id=f'e{i+1:02}',construct=g,text=t) for i,(g,t) in enumerate(pairs)]
def stage_prompt(pack,row,stage):
 st=pack.get('families',{}).get(row.get('family'),pack)[row['study']]
 if stage=='essay':return st['essay_prompts'][row['emotion']],768,None
 if stage=='baseline':return 'Before the writing task, rate how calm, upset, and engaged you feel, each from 0 (not at all) to 8 (extremely). Return only three lines: calm: number; upset: number; engaged: number.',128,('ratings',['calm','upset','engaged'],0,8)
 if stage=='check':
  groups=st['check_items'] if row['study']=='masterson' else st['end_check_items'];intro=st['check_intro'] if row['study']=='masterson' else st['end_check_intro'];items=check_items(groups,row['check_order_seed']);return intro+'\n'+'\n'.join(x['id']+': '+x['text'] for x in items)+'\nReturn only one line per item in the form item_id: number.',256,('ratings',[x['id'] for x in items],1 if row['study']=='masterson' else 0,5 if row['study']=='masterson' else 8)
 if stage=='choice':
  sentences=[st['cost_sentences'][row['cost']],st['status_sentences'][row['status']]]
  if row['sentence_order']=='status_first':sentences.reverse()
  return st['vignette_base']+' '+ ' '.join(sentences)+'\n\n'+st['choice'],96,('choice',['use troops to push back the invaders','stay out militarily'])
 if stage=='strength':return st['strength'],64,('choice',['strongly','not strongly'])
 if stage=='outlook':return st['outlook_intro']+'\n'+'\n'.join(x['id']+': '+x['text'] for x in st['outlook_items'])+'\nReturn only one line per item in the form item_id: number.',256,('ratings',[x['id'] for x in st['outlook_items']],0,8)
 if stage in ['self','peer']:
  intro=st['probability_intro_self' if stage=='self' else 'probability_intro_peer'];return intro+'\n'+'\n'.join(x['id']+': '+x['text'] for x in st['probability_items'])+'\nReturn only one line per item in the form item_id: number.',256,('ratings',[x['id'] for x in st['probability_items']],0,100)
 if stage=='policy':return st['policy_intro']+'\n'+'\n'.join(x['id']+': '+x['text'] for x in st['policy_items'])+'\nReturn only one line per item in the form item_id: number.',160,('ratings',[x['id'] for x in st['policy_items']],1,4)
 raise ValueError(stage)
class Runner:
 def __init__(self):
  self.processor=AutoProcessor.from_pretrained(MODEL,revision=REV,trust_remote_code=False,local_files_only=True);self.tok=self.processor.tokenizer;self.tok.padding_side='left'
  self.model=AutoModelForMultimodalLM.from_pretrained(MODEL,revision=REV,dtype=torch.bfloat16,device_map={'':'cuda:0'},attn_implementation='sdpa',local_files_only=True,trust_remote_code=False).eval()
  assert all(not m._forward_hooks for m in self.model.modules()),'Unexpected activation hook'
 def generate(self,messages,max_new,seed):
  prefixes=[self.processor.apply_chat_template(m,tokenize=False,add_generation_prompt=True,enable_thinking=False) for m in messages]
  inputs=self.processor.apply_chat_template(messages,tokenize=True,padding=True,return_dict=True,return_tensors='pt',add_generation_prompt=True,enable_thinking=False).to('cuda:0')
  width=inputs['input_ids'].shape[1];assert width+max_new<16000
  for i,prefix in enumerate(prefixes):
   unpad=inputs['input_ids'][i][inputs['attention_mask'][i].bool()].tolist();assert self.tok(prefix,add_special_tokens=False)['input_ids']==unpad
  torch.manual_seed(seed);torch.cuda.manual_seed_all(seed);t=time.time()
  with torch.inference_mode():out=self.model.generate(**inputs,do_sample=True,temperature=.7,top_p=.9,top_k=0,max_new_tokens=max_new,use_cache=True,pad_token_id=self.tok.pad_token_id)
  eos=self.model.generation_config.eos_token_id;eos=[eos] if isinstance(eos,int) else list(eos or []);vals=[]
  for i in range(len(messages)):
   ids=out[i,width:].tolist();stop=next((j for j,v in enumerate(ids) if v in eos),None);effective=ids[:stop+1] if stop is not None else ids
   vals.append({'text':self.tok.decode(effective,skip_special_tokens=True).strip(),'raw_text':self.tok.decode(effective,skip_special_tokens=False),'new_token_ids':effective,'input_sha256':hashlib.sha256(prefixes[i].encode()).hexdigest(),'input_tokens':int(inputs['attention_mask'][i].sum()),'sampler_seed':seed,'max_new_tokens':max_new,'truncated':stop is None and len(effective)>=max_new,'stop_token':None if stop is None else ids[stop],'batch_seconds':time.time()-t})
  return vals

def run(args):
 start=time.time();out=ROOT/'results'/args.output;out.mkdir(parents=True,exist_ok=True);pack=json.loads((ROOT/'data'/args.materials).read_text());rows=[json.loads(l) for l in (ROOT/'data'/args.schedule).read_text().splitlines()]
 if args.smoke:
  rows=[]
  for study,emotions in [('masterson',['humiliation','shame','neutral']),('lerner',['fear','anger','sadness','neutral'])]:
   for i,e in enumerate(emotions):rows.append(dict(study=study,emotion=e,cost='high',status='absent',sentence_order='cost_first',rep=0,session_id='smoke_'+study+'_'+e,generation_seed=910000+len(rows),check_order_seed=920000+len(rows)))
 save(out/'protocol.json',{'model':MODEL,'revision':REV,'mode':'smoke' if args.smoke else ('confirmation' if args.materials!='essay_materials_v2.json' else 'fixed_pilot'),'materials_file':args.materials,'schedule_file':args.schedule,'n_sessions':len(rows),'batch_size':args.batch_size,'steering':False,'temperature':.7,'top_p':.9,'top_k':0,'seed_rule':'SHA256 of study,stage and ordered session generation seeds, mod 2^31; batch membership and seeds retained. HF sampling uses independent draws from this batch RNG, not a per-row generator.','format_amendment':'Neutral item_id: number line formatting; baseline equivalent labels; no substantive stimulus change. Frozen before essay outcomes.','pack_sha256':hashlib.sha256((ROOT/'data'/args.materials).read_bytes()).hexdigest(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'schedule':rows})
 runner=Runner();save(out/'environment.json',{'torch':torch.__version__,'transformers':transformers.__version__,'gpu':torch.cuda.get_device_name(),'generation_config':runner.model.generation_config.to_dict()});done=0
 for study in ['masterson','lerner']:
  rr=[r for r in rows if r['study']==study];stages=['essay','check','choice','strength'] if study=='masterson' else ['baseline','essay','outlook','self','peer','policy','check']
  for bi in range(0,len(rr),args.batch_size):
   chunk=rr[bi:bi+args.batch_size];path=out/f'batches/{study}_{bi:04}.json'
   if path.exists():done+=len(chunk);continue
   sessions=[{'assignment':r,'messages':[{'role':'system','content':pack['system']}],'stages':{}} for r in chunk]
   for stage in stages:
    specs=[stage_prompt(pack,s['assignment'],stage) for s in sessions]
    for s,(prompt,_,_) in zip(sessions,specs):s['messages'].append({'role':'user','content':prompt})
    seed=int(hashlib.sha256(json.dumps([study,stage,[r['generation_seed'] for r in chunk]]).encode()).hexdigest()[:8],16)%(2**31)
    vals=runner.generate([s['messages'] for s in sessions],specs[0][1],seed)
    for s,(_,_,parser),v in zip(sessions,specs,vals):
     if parser:
      v['parsed']=parse_ratings(v['text'],*parser[1:]) if parser[0]=='ratings' else parse_choice(v['text'],parser[1])
     if stage=='essay':v['word_count']=len(v['text'].split());v['first_person_marker']=bool(re.search(r'\b(I|my|me)\b',v['text']))
     if stage=='check':v['item_key']=check_items(pack[study]['check_items' if study=='masterson' else 'end_check_items'],s['assignment']['check_order_seed'])
     s['stages'][stage]=v;s['messages'].append({'role':'assistant','content':v['text']})
     if stage!='essay' and 'essay' in s['stages']:assert any(m['role']=='assistant' and m['content']==s['stages']['essay']['text'] for m in s['messages'])
    if args.smoke:print('SMOKE STAGE',study,stage,[(s['assignment']['emotion'],s['stages'][stage].get('parsed',{}).get('valid'),s['stages'][stage]['truncated']) for s in sessions],flush=True)
   save(path,sessions);done+=len(sessions);save(out/'progress.json',{'completed_sessions':done,'total':len(rows),'seconds':time.time()-start});print('PROGRESS',done,'/',len(rows),'seconds',round(time.time()-start,1),flush=True)
 save(out/'completion.json',{'completed':True,'sessions':done,'seconds':time.time()-start,'max_gpu_bytes':torch.cuda.max_memory_allocated(),'steering':False})
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--output',required=True);ap.add_argument('--materials',default='essay_materials_v2.json');ap.add_argument('--schedule',default='essay_schedule_v2.jsonl');ap.add_argument('--smoke',action='store_true');ap.add_argument('--batch-size',type=int,default=4);args=ap.parse_args()
 try:run(args)
 except Exception as e:save(ROOT/'results'/args.output/'error.json',{'error':str(e),'traceback':traceback.format_exc()});raise
